﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MXGP.Models.Motorcycles
{
    public class SpeedMotorcycle : Motorcycle
    {
        public SpeedMotorcycle(string model,int hors):base(model,hors,125)
        {

        }
    }
}
