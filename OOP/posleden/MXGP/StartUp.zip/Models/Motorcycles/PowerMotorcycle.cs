﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MXGP.Models.Motorcycles
{
    public class PowerMotorcycle : Motorcycle
    {
        public PowerMotorcycle(string model,int hors) : base(model,hors,450)
        {
        }
    }
}
